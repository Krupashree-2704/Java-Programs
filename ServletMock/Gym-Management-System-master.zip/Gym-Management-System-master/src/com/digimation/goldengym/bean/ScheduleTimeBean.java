package com.digimation.goldengym.bean;

public class ScheduleTimeBean {
private String 	startTime;
private String 	endTime;
private Integer scheduleTimeId;
public String getStartTime() {
	return startTime;
}
public void setStartTime(String startTime) {
	this.startTime = startTime;
}
public String getEndTime() {
	return endTime;
}
public void setEndTime(String endTime) {
	this.endTime = endTime;
}
public Integer getScheduleTimeId() {
	return scheduleTimeId;
}
public void setScheduleTimeId(Integer scheduleTimeId) {
	this.scheduleTimeId = scheduleTimeId;
}

	
}
