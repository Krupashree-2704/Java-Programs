package com.digimation.goldengym.bean;

public class MemberTypeBean {
	private String memberType;
	private Integer memberTypeId;
	public String getMemberType() {
		return memberType;
	}
	public void setMemberType(String memberType) {
		this.memberType = memberType;
	}
	public Integer getMemberTypeId() {
		return memberTypeId;
	}
	public void setMemberTypeId(Integer memberTypeId) {
		this.memberTypeId = memberTypeId;
	}

}
