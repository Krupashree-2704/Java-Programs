package com.digimation.goldengym.bean;

public class ActivityBean {
private String activity;
private Integer activityId;
public String getActivity() {
	return activity;
}
public void setActivity(String activity) {
	this.activity = activity;
}
public Integer getActivityId() {
	return activityId;
}
public void setActivityId(Integer activityId) {
	this.activityId = activityId;
}


}
