package com.digimation.goldengym.bean;

public class TrainerBean {

	
private Integer trainerId;
private String firstName;
private String lastName;
private String email;
private String password;
private String address;
private String gender;
private String mobile;
private Integer cityId;
private String city;
private String isActive;
private String dob;
private Integer experiance;
private String photo;

public String getPhoto() {
	return photo;
}
public void setPhoto(String photo) {
	this.photo = photo;
}
public Integer getExperiance() {
	return experiance;
}
public void setExperiance(Integer experiance) {
	this.experiance = experiance;
}
public String getDob() {
	return dob;
}
public void setDob(String dob) {
	this.dob = dob;
}
public String getIsActive() {
	return isActive;
}
public void setIsActive(String isActive) {
	this.isActive = isActive;
}
public Integer getTrainerId() {
	return trainerId;
}
public void setTrainerId(Integer trainerId) {
	this.trainerId = trainerId;
}
public String getCity() {
	return city;
}
public void setCity(String city) {
	this.city = city;
}
public String getFirstName() {
	return firstName;
}
public void setFirstName(String firstName) {
	this.firstName = firstName;
}
public String getLastName() {
	return lastName;
}
public void setLastName(String middleName) {
	this.lastName = middleName;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}
public String getGender() {
	return gender;
}
public void setGender(String gender) {
	this.gender = gender;
}
public String getMobile() {
	return mobile;
}
public void setMobile(String mobile) {
	this.mobile = mobile;
}
public Integer getCityId() {
	return cityId;
}
public void setCityId(Integer cityId) {
	this.cityId = cityId;
}

}
