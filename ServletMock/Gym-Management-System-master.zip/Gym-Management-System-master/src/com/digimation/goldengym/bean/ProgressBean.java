package com.digimation.goldengym.bean;

public class ProgressBean extends MemberBean{
private int progressId;
private String startDate;
private String endDate;
public int getProgressId() {
	return progressId;
}
public void setProgressId(int progressId) {
	this.progressId = progressId;
}
public String getStartDate() {
	return startDate;
}
public void setStartDate(String startDate) {
	this.startDate = startDate;
}
public String getEndDate() {
	return endDate;
}
public void setEndDate(String endDate) {
	this.endDate = endDate;
}


}

