# Gym-Management-System
 This system helps gym member and trainers to maintain details of work like progress card,diet,schedule,etc. 
 
 Technologies
  - Back-end : JSP-Servlet
  - Front-end : Bootstrap,Html,Jquery 
  - Database : MySQl
  - Architecture : MVC
  - Development Tool : Eclipse
  - Server : Apache tomcat 7 

