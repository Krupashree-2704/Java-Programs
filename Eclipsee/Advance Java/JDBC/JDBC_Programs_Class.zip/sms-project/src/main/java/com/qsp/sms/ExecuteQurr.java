package com.qsp.sms;

public class ExecuteQurr {

	
	

	public static boolean insertRecord(Student s) {
		// TODO Auto-generated method stub
		return false;
	}
	public static void readRecord(Student s)
	{
		
	}
	public static boolean deleteRecord(int id) {
		// TODO Auto-generated method stub
		return false;
	}
	public static boolean updateRecord(Student s2) {
		return false;
		// TODO Auto-generated method stub
		
	}

}
